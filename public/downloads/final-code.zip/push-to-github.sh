#!/bin/bash

# Ambica Pharma Code Push Script
# Run this after extracting the zip file

echo "🚀 Starting GitHub push process..."

# Initialize git
git init
echo "✓ Git initialized"

# Add remote
git remote add origin https://github.com/yashaasmo/vigyan.git
echo "✓ Remote added"

# Checkout main branch
git checkout -b main
echo "✓ Branch created"

# Add all files
git add .
echo "✓ Files added"

# Commit
git commit -m "Added Ambica Pharma clone website - Complete React app"
echo "✓ Committed"

# Push to GitHub
echo "📤 Pushing to GitHub..."
echo "Note: You'll need to enter your GitHub username and password/token"
git push -u origin main

echo "✅ Done! Check your repo at: https://github.com/yashaasmo/vigyan"
