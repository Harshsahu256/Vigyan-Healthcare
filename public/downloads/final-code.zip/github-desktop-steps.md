# GitHub Desktop Se Code Upload Karein

## Steps:

1. **GitHub Desktop Install Karo** (Agar nahi hai)
   - Download: https://desktop.github.com/

2. **Login Karo**
   - Apne GitHub account se login karo

3. **Repository Clone Karo**
   - File → Clone Repository
   - URL: `https://github.com/yashaasmo/vigyan.git`
   - Local path choose karo

4. **Code Copy Karo**
   - Downloaded zip ko extract karo
   - Saare files clone ki hui folder mein copy karo

5. **Commit & Push**
   - GitHub Desktop mein changes dikhengi
   - Commit message: "Added Ambica Pharma clone"
   - "Push to origin" button dabao

✅ Done!
