// Mock data for Ambica Pharma clone

export const companyInfo = {
  name: "Ambica Pharma",
  tagline: "Leading Pharmaceutical Wholesaler, Trader & Exporter in India",
  established: "2005",
  yearsOfExperience: "19+",
  description: "Ambica Pharma has evolved from a humble startup into a leading force in pharmaceutical distribution. With over 19 years of expertise, we pride ourselves on quality, service, and client satisfaction."
};

export const certifications = [
  {
    id: 1,
    title: "WHO–GMP Units",
    description: "Audited multi-therapeutic lines",
    icon: "shield-check"
  },
  {
    id: 2,
    title: "ISO 9001:2015",
    description: "Documented QMS + GDP SOPs",
    icon: "award"
  },
  {
    id: 3,
    title: "Cold-Chain Ready",
    description: "2–8°C monitored fulfillment",
    icon: "thermometer"
  },
  {
    id: 4,
    title: "Global Export Desk",
    description: "45+ regulated & semi-regulated markets",
    icon: "globe"
  }
];

export const stats = [
  {
    id: 1,
    number: "45+",
    label: "Countries Served",
    icon: "globe"
  },
  {
    id: 2,
    number: "300k+",
    label: "Healthcare Partners",
    icon: "users"
  },
  {
    id: 3,
    number: "5k+",
    label: "Formulations",
    icon: "pill"
  },
  {
    id: 4,
    number: "35+",
    label: "Awards & Citations",
    icon: "trophy"
  }
];

export const productCategories = [
  {
    id: 1,
    title: "Tablets & Capsules",
    tags: ["Generics", "Branded", "Bulk Supply"],
    description: "From common generics to specialty formulations — antibiotics, analgesics, vitamins, cardiac care, and more. Bulk or retail, we source it all.",
    image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600&q=80"
  },
  {
    id: 2,
    title: "Injectables & Vials",
    tags: ["IV Solutions", "Ampoules", "Tender Ready"],
    description: "Hospital-grade injectables, ampoules, and lyophilized products. Cold-chain ready with complete documentation for tenders.",
    image: "https://images.unsplash.com/photo-1631549916768-4119b2e5f926?w=600&q=80"
  },
  {
    id: 3,
    title: "Syrups & Suspensions",
    tags: ["Pediatric", "OTC Range", "Multi-Pack"],
    description: "Pediatric formulations, cough syrups, antacids, and nutraceutical liquids. Available in multiple pack sizes for retail and wholesale.",
    image: "https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=600&q=80"
  },
  {
    id: 4,
    title: "Specialty & Nutraceuticals",
    tags: ["Derma", "Wellness", "Custom Sourcing"],
    description: "Derma care, wellness supplements, ayurvedic products, and cosmeceuticals. If you need it, we can arrange manufacturing or sourcing.",
    image: "https://images.unsplash.com/photo-1556228852-80a0ac0a6cf7?w=600&q=80"
  }
];

export const supplySolutions = [
  {
    id: 1,
    title: "Hospital & Institutional Supply",
    description: "Aggregator model for tertiary care hospitals, group purchasing organizations, and state tenders.",
    features: [
      "Therapeutic bundling by specialty",
      "On-site pharmacovigilance kits",
      "Quarterly demand forecasting"
    ]
  },
  {
    id: 2,
    title: "International Private Label",
    description: "Concept-to-market support for distributors expanding their house brand portfolio.",
    features: [
      "Artwork + dossier support",
      "Flexible MOQ & blistering",
      "Regulatory document library"
    ]
  },
  {
    id: 3,
    title: "Digital & Retail Pharmacies",
    description: "Rapid replenishment for omnichannel pharmacies and telehealth platforms.",
    features: [
      "Same-week dispatch for 200+ SKUs",
      "Smart lot traceability",
      "Cold-chain add-ons"
    ]
  },
  {
    id: 4,
    title: "Specialty Clinics & Wellness Chains",
    description: "Curated therapy bundles for aesthetic, fertility, and wellness group practices.",
    features: [
      "Cross-therapy starter kits",
      "White-glove shelf readiness",
      "Dedicated clinical educator desk"
    ]
  }
];

export const qualityFeatures = [
  {
    id: 1,
    title: "Regulatory Confidence",
    description: "WHO–GMP, ISO 9001, and GDP aligned operations audited every 6 months."
  },
  {
    id: 2,
    title: "Manufacturing Depth",
    description: "Dedicated beta-lactam, hormonal, and general formulation blocks with HEPA controls."
  },
  {
    id: 3,
    title: "Secure Logistics",
    description: "Validated 2–8°C boxes, GPS-enabled fleet, and serialized cartons for exports."
  },
  {
    id: 4,
    title: "Documentation Desk",
    description: "Dossier compilation, COA sharing, and CTD-ready paperwork for quick filings."
  }
];

export const operationalStats = [
  {
    id: 1,
    number: "19",
    label: "Years of Marketing & Distribution"
  },
  {
    id: 2,
    number: "900K+",
    label: "Happy Customers"
  },
  {
    id: 3,
    number: "22",
    label: "Years of Experience"
  },
  {
    id: 4,
    number: "5000+",
    label: "Quality Products"
  }
];

export const supplyChainStats = [
  {
    id: 1,
    number: "600+",
    label: "Hospital partners",
    sublabel: "Aggregator & tender-ready"
  },
  {
    id: 2,
    number: "120+",
    label: "Private label launches",
    sublabel: "Concept-to-commercialization"
  },
  {
    id: 3,
    number: "80+",
    label: "SKUs with cold chain",
    sublabel: "Validated insulated shipping"
  }
];
