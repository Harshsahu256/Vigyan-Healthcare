# Ambica Pharma Clone Website

A pixel-perfect clone of [Ambica Pharma](https://ambicapharma.net/) - a leading pharmaceutical wholesaler, trader, and exporter website built with React.js.

## 🌟 Features

- **Responsive Design**: Fully responsive layout that works on all devices
- **Modern UI/UX**: Clean, professional pharmaceutical aesthetic with blue-to-teal gradient theme
- **Multiple Pages**: Home, About Us, Contact, Privacy Policy
- **Interactive Components**: 
  - Cookie consent modal
  - WhatsApp & chat floating buttons
  - Navigation with dropdown
  - Contact form with validation
  
## 🛠️ Tech Stack

### Frontend
- **React.js** - UI framework
- **Tailwind CSS** - Styling
- **React Router** - Navigation
- **Shadcn/ui** - UI components
- **Lucide React** - Icons

### Backend (Optional)
- **FastAPI** - Python web framework
- **MongoDB** - Database
- **Motor** - Async MongoDB driver

## 📦 Installation

### Prerequisites
- Node.js (v16 or higher)
- npm or yarn
- Python 3.8+ (for backend, optional)

### Frontend Setup

```bash
# Clone the repository
git clone https://github.com/yashaasmo/vigyan.git
cd vigyan

# Navigate to frontend
cd frontend

# Install dependencies
yarn install
# or
npm install

# Start development server
yarn start
# or
npm start
```

The app will run on `http://localhost:3000`

### Backend Setup (Optional)

```bash
# Navigate to backend
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\\Scripts\\activate

# Install dependencies
pip install -r requirements.txt

# Run the server
python server.py
```

The API will run on `http://localhost:8001`

## 📁 Project Structure

```
vigyan/
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── components/
│   │   │   ├── ui/              # Shadcn UI components
│   │   │   ├── Navbar.jsx
│   │   │   ├── HeroSection.jsx
│   │   │   ├── ProductsSection.jsx
│   │   │   ├── Footer.jsx
│   │   │   └── ...
│   │   ├── pages/
│   │   │   ├── HomePage.jsx
│   │   │   ├── AboutPage.jsx
│   │   │   ├── ContactPage.jsx
│   │   │   └── PrivacyPage.jsx
│   │   ├── mock/
│   │   │   └── data.js          # Mock data
│   │   ├── hooks/
│   │   ├── App.js
│   │   └── index.js
│   ├── package.json
│   └── tailwind.config.js
└── backend/
    ├── server.py
    └── requirements.txt
```

## 🎨 Design Features

- **Color Scheme**: Blue to teal gradient theme
- **Certifications Section**: WHO-GMP, ISO 9001:2015 certified badges
- **Product Categories**: Tablets, Injectables, Syrups, Specialty medicines
- **Stats Section**: Global reach statistics (45+ countries, 300k+ partners)
- **Supply Solutions**: Hospital, International, Digital pharmacy solutions

## 🌐 Pages

1. **Home** - Complete landing page with all sections
2. **About Us** - Company information and achievements
3. **Contact** - Contact form and company details
4. **Privacy Policy** - Privacy and data usage information

## 📱 Responsive Breakpoints

- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

## 🔧 Configuration

### Environment Variables

Create a `.env` file in the frontend directory:

```env
REACT_APP_BACKEND_URL=http://localhost:8001
```

## 🚀 Deployment

### Frontend (Vercel/Netlify)

```bash
# Build for production
cd frontend
yarn build

# Deploy the build folder
```

### Backend (Railway/Heroku)

```bash
cd backend
# Follow platform-specific deployment instructions
```

## 📝 Mock Data

All data is currently mocked in `/frontend/src/mock/data.js`. This includes:
- Company information
- Certifications
- Product categories
- Statistics
- Supply solutions

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

This is a clone project for educational purposes.

## 👨‍💻 Developer

Created with ❤️ using [Emergent.sh](https://emergent.sh)

## 📞 Support

For any queries or support, please contact through the GitHub issues page.

---

⭐ If you find this project useful, please consider giving it a star!
